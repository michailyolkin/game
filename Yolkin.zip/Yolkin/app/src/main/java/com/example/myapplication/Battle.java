package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class Battle extends AppCompatActivity {
	private int playerCountry;
	private int enemyCountry;
	private TextView eHealth,ePower,eMoney,mHealth,mPower,mMoney,bturn;
	private ImageView mIcon, eIcon;
	private int turn = 1;
	private Country player;
	private Country enemy;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_battle);
		playerCountry = MainActivity.playerChoice;
		enemyCountry = MainActivity.enemyChoice;

		eHealth = findViewById(R.id.enemyHealth);
		eMoney = findViewById(R.id.enemyMoney);
		ePower = findViewById(R.id.enemyPower);
		mHealth = findViewById(R.id.myHealth);
		mPower = findViewById(R.id.myPower);
		mMoney = findViewById(R.id.myMoney);
		bturn = findViewById(R.id.bturn);
		mIcon = findViewById(R.id.myIcon);
		eIcon = findViewById(R.id.enemyIcon);

		player = new Country(CountiesList.values()[playerCountry], mHealth, mPower, mMoney);
		enemy = new Country(CountiesList.values()[enemyCountry], eHealth, ePower, eMoney);

		Button hit = (Button) findViewById(R.id.HIT);
		hit.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (player.hit(enemy)) {
					enemyTurn();
				}

			}
		});
		Button defend = (Button) findViewById(R.id.DEFEND);
		defend.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (player.defend()) {
					enemyTurn();
				}


			}
		});

		Button buy = (Button) findViewById(R.id.BUY);
		buy.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (player.buy()) {
					enemyTurn();
				}

			}
		});
	}

	@Override
	protected void onResume() {
		super.onResume();
		if (player != null) {
			mIcon.setImageResource(player.getResourceImage());
			mHealth.setText(player.getHealth()+"");
			mPower.setText(player.getPower()+"");
			mMoney.setText(player.getMoney()+"");
		}

		if (enemy != null) {
			eIcon.setImageResource(enemy.getResourceImage());
			eHealth.setText(enemy.getHealth()+"");
			ePower.setText(enemy.getPower()+"");
			eMoney.setText(enemy.getMoney()+"");
		}

	}

	private void enemyTurn(){

		switch (new Random(System.currentTimeMillis()).nextInt(3)) {
			case 0:
				enemy.hit(player);
				break;
			case 1:
				enemy.defend();
				break;
			case 2:
				enemy.buy();
		}

		turn++;
		bturn.setText(turn + "");
	}
}
