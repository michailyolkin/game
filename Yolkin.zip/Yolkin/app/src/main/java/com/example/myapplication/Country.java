package com.example.myapplication;

import android.widget.TextView;

public class Country {
	private int resourceImage;
	private int power;
	private int health;
	private int money;
	private int dMoney;
	private int dPower;
	private int dHealth;
	private TextView healthView;
	private TextView powerView;
	private TextView moneyView;

	public Country(CountiesList country, TextView healthView, TextView powerView, TextView moneyView) {
		this.resourceImage = country.imageResource;
		this.health = country.health;
		this.dHealth = country.dHealth;
		this.power = country.power;
		this.dPower = country.dPower;
		this.money = country.money;
		this.dMoney = country.dMoney;
		this.healthView = healthView;
		this.powerView = powerView;
		this.moneyView = moneyView;
	}

	public int getResourceImage() {
		return resourceImage;
	}

	public int getPower() {
		return power;
	}

	public int getHealth() {
		return health;
	}

	public int getMoney() {
		return money;
	}

	public boolean hit(Country enemy) {
		money += dMoney;
		enemy.takeDamage(power);
		updateViews();
		return true;
	}

	public boolean takeDamage(int damage) {
		boolean result = true;
		health -= damage;
		if (health <= 0) {
			this.resourceImage = CountiesList.DEAD.imageResource;
			result = false;
		}
		updateViews();
		return result;
	}

	public boolean defend() {
		money += dMoney * 4;
		updateViews();
		return true;
	}

	public boolean buy() {
		if (money >= dMoney * 10) {
			money -= dMoney * 10;
			health += dHealth;
			power += dPower;

			updateViews();
			return true;
		} else {
			return false;
		}

	}

	private void updateViews() {
		healthView.setText(health + "");
		powerView.setText(power + "");
		moneyView.setText(money + "");
	}
}
