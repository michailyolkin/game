package com.example.myapplication;

public enum CountiesList {
	DEAD(R.drawable.dead, 0, 0, 0, 0, 0, 0),
	USA(R.drawable.usa, 10, 5, 10, 5, 10, 5),
	RUSSIA(R.drawable.russia, 10, 5, 10, 5, 10, 5),
	GB(R.drawable.gb, 10, 5, 10, 5, 10, 5),
	CHINA(R.drawable.china, 10, 5, 10, 5, 10, 5),
	FRANCE(R.drawable.france, 10, 5, 10, 5, 10, 5),
	ITALY(R.drawable.italy, 10, 5, 10, 5, 10, 5),
	BRAZIL(R.drawable.brazil, 10, 5, 10, 5, 10, 5),
	MEXICO(R.drawable.mexico, 10, 5, 10, 5, 10, 5),
	;

	int imageResource;
	int health;
	int dHealth;
	int power;
	int dPower;
	int money;
	int dMoney;

	CountiesList(int imageResource, int health, int dHealth, int power, int dPower, int money,
			int dMoney) {
		this.imageResource = imageResource;
		this.health = health;
		this.dHealth = dHealth;
		this.power = power;
		this.dPower = dPower;
		this.money = money;
		this.dMoney = dMoney;
	}
}
