package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class ActivityMine extends AppCompatActivity {
int WhichCountryChoosen = 8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mine);
        ImageButton usa = (ImageButton) findViewById(R.id.USA);
        usa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               WhichCountryChoosen = 1;
                countryClick();
           }

});   ImageButton russia = (ImageButton) findViewById(R.id.Russia);
       russia.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                      WhichCountryChoosen = 2;
                    countryClick();
                }});ImageButton greatBritain = (ImageButton) findViewById(R.id.Great_Britain);
        greatBritain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 WhichCountryChoosen = 3;
                 countryClick();
            }});
        ImageButton china = (ImageButton) findViewById(R.id.China);
        china.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 WhichCountryChoosen = 4;
                 countryClick();
            }});
        ImageButton france = (ImageButton) findViewById(R.id.France);
        france.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 WhichCountryChoosen = 5;
                 countryClick();
            }});
        ImageButton italy = (ImageButton) findViewById(R.id.Italy);
        italy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 WhichCountryChoosen = 6;
                 countryClick();
            }});
        ImageButton brazil = (ImageButton) findViewById(R.id.Brazil);
        brazil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WhichCountryChoosen = 7;
                countryClick();
            }});
        ImageButton mexico = (ImageButton) findViewById(R.id.Mexico);
        mexico.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WhichCountryChoosen = 8;
                countryClick();
            }});}


       private  void countryClick(){
        MainActivity.playerChoice = WhichCountryChoosen;
          Intent intent = new Intent( this, MainActivity.class);
          startActivity(intent);
       }
    }
