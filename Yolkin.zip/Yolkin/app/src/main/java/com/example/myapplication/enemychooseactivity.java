package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.ImageButton;

public class enemychooseactivity extends AppCompatActivity {
int whichEnemyCountryChoosen = 8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enemychooseactivity);
        ImageButton usa = (ImageButton) findViewById(R.id.enemyUSA);
        usa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                whichEnemyCountryChoosen = 1;
                enemyCountryClick();
            }

        });   ImageButton enemyrussia = (ImageButton) findViewById(R.id.enemyRussia);
        enemyrussia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                whichEnemyCountryChoosen = 2;
                enemyCountryClick();
            }});ImageButton enemygreatBritain = (ImageButton) findViewById(R.id.enemyGreat_Britain);
        enemygreatBritain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                whichEnemyCountryChoosen = 3;
                enemyCountryClick();
            }});
        ImageButton enemychina = (ImageButton) findViewById(R.id.enemyChina);
        enemychina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                whichEnemyCountryChoosen = 4;
                enemyCountryClick();
            }});
        ImageButton enemyfrance = (ImageButton) findViewById(R.id.enemyFrance);
        enemyfrance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                whichEnemyCountryChoosen = 5;
                enemyCountryClick();
            }});
        ImageButton enemyitaly = (ImageButton) findViewById(R.id.enemyItaly);
        enemyitaly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                whichEnemyCountryChoosen = 6;
                enemyCountryClick();
            }});
        ImageButton enemybrazil = (ImageButton) findViewById(R.id.enemyBrazil);
        enemybrazil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                whichEnemyCountryChoosen = 7;
                enemyCountryClick();
            }});
        ImageButton enemymexico = (ImageButton) findViewById(R.id.enemyMexico);
        enemymexico.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                whichEnemyCountryChoosen = 8;
                enemyCountryClick();
            }});}


    private  void enemyCountryClick(){
        MainActivity.enemyChoice = whichEnemyCountryChoosen;
        Intent intent = new Intent( this, MainActivity.class);
        startActivity(intent);
    }
}